#pragma once
#include <vector>
#include <random>
#include <unordered_set>
#include <algorithm>
#include "individual.h"
#include "readdata.h"

class Mutation {
public:
    static constexpr double SHAKING_PERCENT = 0.6; // default; overridden at runtime

    // Destroy-and-repair mutation.
    static void apply(
        Individual& ind,
        const Data& data,
        std::mt19937& rng,
        double shakingPercent = 0.6
    );

private:
    static double calcDist(const std::vector<int>& seq, const Data& data);
    static void repair(Individual& ind, const Data& data);
    static void rebuild(Individual& ind, const Data& data);
};