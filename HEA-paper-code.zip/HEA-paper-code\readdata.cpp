#include "readdata.h"
#include <cmath>
#include <fstream>
#include <stdexcept>

void readData(const std::string& filename, Data& data) {
    std::ifstream file(filename);
    if (!file)
        throw std::runtime_error("Cannot open instance: " + filename);
    if (!(file >> data.n >> data.Tmax >> data.NC))
        throw std::runtime_error("Invalid instance header");

    data.x_coord.resize(data.n + 1);
    data.y_coord.resize(data.n + 1);
    data.si.resize(data.n + 1);
    data.category.resize(data.n + 1);
    data.tij.assign(
        data.n + 1, std::vector<double>(data.n + 1, 0.0));
    data.bic.assign(
        data.n + 1, std::vector<int>(data.NC + 1, 0));
    data.alpha.resize(data.NC + 1);

    for (int category = 1; category <= data.NC; ++category) {
        if (!(file >> data.alpha[category]))
            throw std::runtime_error("Invalid category factors");
    }
    for (int node = 1; node <= data.n; ++node) {
        if (!(file >> data.x_coord[node] >> data.y_coord[node]
                   >> data.si[node] >> data.category[node])) {
            throw std::runtime_error("Invalid node data");
        }
    }

    for (int i = 1; i <= data.n; ++i) {
        for (int j = 1; j <= data.n; ++j) {
            data.tij[i][j] = std::hypot(
                data.x_coord[i] - data.x_coord[j],
                data.y_coord[i] - data.y_coord[j]);
        }
    }
    for (int node = 1; node <= data.n; ++node) {
        int category = data.category[node];
        if (category < 0 || category > data.NC)
            throw std::runtime_error("Invalid category index");
        data.bic[node][category] = 1;
    }
}
