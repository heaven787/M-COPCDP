#pragma once
#include <vector>
#include <random>
#include <unordered_set>
#include <algorithm>
#include <utility>
#include "individual.h"
#include "readdata.h"

class Crossover {
public:
    // LCS backbone crossover from Section 3.3.1.
    static std::pair<Individual, Individual> apply(
        const Individual& p1,
        const Individual& p2,
        const Data& data,
        std::mt19937& rng
    );

private:
    static double calcTotalDist(const std::vector<int>& seq, const Data& data);
    static void repair(Individual& ind, const Data& data);
    static void rebuild(Individual& ind, const Data& data);
};