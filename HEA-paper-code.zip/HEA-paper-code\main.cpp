#include <atomic>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include "HeaConfig.h"
#include "LocalSearch.h"
#include "Popmanage.h"
#include "readdata.h"

namespace {
void validateSolution(const Individual& solution, const Data& data) {
    if (solution.sequence.size() < 2 ||
        solution.sequence.front() != 1 ||
        solution.sequence.back() != 2) {
        throw std::runtime_error("Invalid route terminals");
    }
    std::unordered_set<int> seen;
    for (size_t i = 1; i + 1 < solution.sequence.size(); ++i) {
        int node = solution.sequence[i];
        if (node < 3 || node > data.n || !seen.insert(node).second)
            throw std::runtime_error("Invalid or duplicate POI");
    }
    if (solution.travelTime > data.Tmax + 1e-7)
        throw std::runtime_error("Final route exceeds the time budget");
}

HeaConfig parseConfig(int argc, char* argv[], int& instanceIndex, unsigned int& seed) {
    HeaConfig config = HeaConfig::defaults();
    if (argc < 2) {
        throw std::runtime_error("Usage: cop_hea <instance.COPCDP> [seed] [--key=value ...]");
    }
    instanceIndex = 1;
    int argIndex = 2;
    if (argc >= 3 && argv[2][0] != '-') {
        seed = static_cast<unsigned int>(std::stoul(argv[2]));
        argIndex = 3;
    } else {
        seed = 123U;
    }
    for (int i = argIndex; i < argc; ++i) {
        std::string token = argv[i];
        if (token.rfind("--", 0) != 0) {
            throw std::runtime_error("Unexpected argument: " + token);
        }
        const auto eq = token.find('=');
        if (eq == std::string::npos) {
            throw std::runtime_error("Expected --key=value, got: " + token);
        }
        config.applyFlag(token.substr(2, eq - 2), token.substr(eq + 1));
    }
    return config;
}
}

int main(int argc, char* argv[]) {
    try {
        unsigned int seed = 123U;
        int instanceIndex = 1;
        HeaConfig config = parseConfig(argc, argv, instanceIndex, seed);

        Data data;
        readData(argv[instanceIndex], data);
        Popmanage population(seed, config);
        LocalSearch localSearch(data, seed + 0x9e3779b9U);
        localSearch.setParameters(config.tabuDepth, config.threeOptFreq,
                                  config.penaltyFreq, config.tenureFactor);
        std::atomic<bool> stopRequested(false);

        auto start = std::chrono::steady_clock::now();
        Individual best =
            population.evolve(data, localSearch, stopRequested);
        double seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - start).count();
        validateSolution(best, data);

        std::cout << std::fixed << std::setprecision(10);
        std::cout << "RESULT objective=" << best.objective
                  << " distance=" << best.travelTime
                  << " cpu=" << seconds
                  << " seed=" << seed
                  << " route=";
        for (size_t i = 0; i < best.sequence.size(); ++i) {
            if (i) std::cout << ',';
            std::cout << best.sequence[i];
        }
        std::cout << '\n';
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
