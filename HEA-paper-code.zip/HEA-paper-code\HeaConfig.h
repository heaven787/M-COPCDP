#ifndef HEA_CONFIG_H
#define HEA_CONFIG_H

#include <string>

struct HeaConfig {
    int popSize = 10;
    int eliteCount = 3;
    int maxGen = 10;
    int stagnationLim = 5;
    double simThreshold = 0.8;
    double shakingPercent = 0.6;
    int tabuDepth = 80;
    int threeOptFreq = 5;
    int penaltyFreq = 5;
    double tenureFactor = 0.1;

    static HeaConfig defaults() { return HeaConfig{}; }

    void applyFlag(const std::string& key, const std::string& value);
};

#endif
