#include "individual.h"
#include <algorithm>

void Individual::recomputeScores(const Data& data) {
    counts.assign(data.NC + 1, 0);
    categorySums.assign(data.NC + 1, 0.0);
    categories.assign(sequence.size(), 0);
    scores.assign(sequence.size(), 0.0);
    objective = 0.0;
    travelTime = 0.0;

    for (int node : sequence) {
        if (node < 1 || node > data.n || node == 1 || node == 2) continue;
        int c = data.category[node];
        if (c >= 1 && c <= data.NC) {
            ++counts[c];
            categorySums[c] += data.si[node];
        }
    }

    for (size_t i = 0; i < sequence.size(); ++i) {
        int node = sequence[i];
        if (node < 1 || node > data.n || node == 1 || node == 2) continue;
        int c = data.category[node];
        categories[i] = c;
        if (c >= 1 && c <= data.NC) {
            double denominator = (1.0 - data.alpha[c]) * (counts[c] + 1);
            if (denominator > 1e-9) {
                scores[i] = static_cast<double>(data.si[node]) / denominator;
                objective += scores[i];
            }
        }
    }

    for (size_t i = 0; i + 1 < sequence.size(); ++i) {
        travelTime += data.tij[sequence[i]][sequence[i + 1]];
    }
}