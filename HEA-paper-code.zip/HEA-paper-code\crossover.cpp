#include "crossover.h"

namespace {
std::vector<int> longestCommonSubsequence(
    const std::vector<int>& a, const std::vector<int>& b) {
    std::vector<std::vector<int>> dp(
        a.size() + 1, std::vector<int>(b.size() + 1, 0));
    for (size_t i = 1; i <= a.size(); ++i) {
        for (size_t j = 1; j <= b.size(); ++j) {
            dp[i][j] = a[i - 1] == b[j - 1]
                ? dp[i - 1][j - 1] + 1
                : std::max(dp[i - 1][j], dp[i][j - 1]);
        }
    }

    std::vector<int> result;
    size_t i = a.size();
    size_t j = b.size();
    while (i > 0 && j > 0) {
        if (a[i - 1] == b[j - 1]) {
            result.push_back(a[i - 1]);
            --i;
            --j;
        } else if (dp[i - 1][j] >= dp[i][j - 1]) {
            --i;
        } else {
            --j;
        }
    }
    std::reverse(result.begin(), result.end());
    return result;
}

std::vector<std::vector<int>> splitByBackbone(
    const std::vector<int>& parent, const std::vector<int>& backbone) {
    std::vector<std::vector<int>> segments(backbone.size() + 1);
    size_t segment = 0;
    for (int node : parent) {
        if (segment < backbone.size() && node == backbone[segment]) {
            ++segment;
        } else {
            segments[segment].push_back(node);
        }
    }
    return segments;
}
}

double Crossover::calcTotalDist(
    const std::vector<int>& sequence, const Data& data) {
    double distance = 0.0;
    for (size_t i = 0; i + 1 < sequence.size(); ++i)
        distance += data.tij[sequence[i]][sequence[i + 1]];
    return distance;
}

void Crossover::rebuild(Individual& ind, const Data& data) {
    ind.recomputeScores(data);
}

void Crossover::repair(Individual& ind, const Data& data) {
    std::unordered_set<int> seen;
    std::vector<int> clean;
    for (int node : ind.sequence) {
        if (node == 2 || (node == 1 && !clean.empty())) continue;
        if (seen.insert(node).second) clean.push_back(node);
    }
    if (clean.empty() || clean.front() != 1) clean.insert(clean.begin(), 1);
    clean.push_back(2);
    ind.sequence = std::move(clean);

    while (calcTotalDist(ind.sequence, data) > data.Tmax &&
           ind.sequence.size() > 2) {
        ind.sequence.erase(ind.sequence.end() - 2);
    }
    rebuild(ind, data);
}

std::pair<Individual, Individual> Crossover::apply(
    const Individual& p1,
    const Individual& p2,
    const Data& data,
    std::mt19937& rng) {
    std::vector<int> a;
    std::vector<int> b;
    if (p1.sequence.size() > 2)
        a.assign(p1.sequence.begin() + 1, p1.sequence.end() - 1);
    if (p2.sequence.size() > 2)
        b.assign(p2.sequence.begin() + 1, p2.sequence.end() - 1);

    Individual child1;
    Individual child2;
    child1.sequence = {1};
    child2.sequence = {1};
    std::vector<int> backbone = longestCommonSubsequence(a, b);

    if (backbone.empty()) {
        size_t i = 0;
        size_t j = 0;
        std::uniform_int_distribution<int> choose(0, 1);
        while (i < a.size() || j < b.size()) {
            bool takeA = j == b.size() || (i < a.size() && choose(rng) == 0);
            child1.sequence.push_back(takeA ? a[i++] : b[j++]);
        }
        i = 0;
        j = 0;
        while (i < a.size() || j < b.size()) {
            bool takeB = i == a.size() || (j < b.size() && choose(rng) == 0);
            child2.sequence.push_back(takeB ? b[j++] : a[i++]);
        }
    } else {
        auto segmentsA = splitByBackbone(a, backbone);
        auto segmentsB = splitByBackbone(b, backbone);
        for (size_t segment = 0; segment < segmentsA.size(); ++segment) {
            const auto& first =
                segment % 2 == 0 ? segmentsA[segment] : segmentsB[segment];
            const auto& second =
                segment % 2 == 0 ? segmentsB[segment] : segmentsA[segment];
            child1.sequence.insert(
                child1.sequence.end(), first.begin(), first.end());
            child2.sequence.insert(
                child2.sequence.end(), second.begin(), second.end());
            if (segment < backbone.size()) {
                child1.sequence.push_back(backbone[segment]);
                child2.sequence.push_back(backbone[segment]);
            }
        }
    }

    child1.sequence.push_back(2);
    child2.sequence.push_back(2);
    repair(child1, data);
    repair(child2, data);
    return {child1, child2};
}
