#ifndef POPMANAGE_H
#define POPMANAGE_H

#include <atomic>
#include <random>
#include <vector>
#include "HeaConfig.h"
#include "LocalSearch.h"
#include "individual.h"
#include "readdata.h"

class Popmanage {
public:
    static constexpr int TOURNAMENT_K = 3;

    explicit Popmanage(unsigned int seed = 123,
                       HeaConfig config = HeaConfig::defaults());
    Individual evolve(const Data& data, LocalSearch& localSearch,
                      const std::atomic<bool>& stopRequested);
    const std::vector<Individual>& population() const { return pool; }

private:
    HeaConfig config;
    std::vector<Individual> pool;
    Individual best;
    std::mt19937 rng;

    double evaluate(const Individual& ind) const;
    Individual randomizedGreedy(const Data& data);
    void initialize(const Data& data);
    const Individual& tournamentSelect();
    double jaccardSimilarity(const Individual& first,
                             const Individual& second) const;
};

#endif
