#include "mo.h"
#include <cmath>

double Mutation::calcDist(
    const std::vector<int>& sequence, const Data& data) {
    double distance = 0.0;
    for (size_t i = 0; i + 1 < sequence.size(); ++i)
        distance += data.tij[sequence[i]][sequence[i + 1]];
    return distance;
}

void Mutation::rebuild(Individual& ind, const Data& data) {
    ind.recomputeScores(data);
}

void Mutation::repair(Individual& ind, const Data& data) {
    std::unordered_set<int> seen;
    std::vector<int> clean;
    for (int node : ind.sequence) {
        if (node == 2 || (node == 1 && !clean.empty())) continue;
        if (seen.insert(node).second) clean.push_back(node);
    }
    if (clean.empty() || clean.front() != 1) clean.insert(clean.begin(), 1);
    clean.push_back(2);
    ind.sequence = std::move(clean);

    while (calcDist(ind.sequence, data) > data.Tmax &&
           ind.sequence.size() > 2) {
        ind.sequence.erase(ind.sequence.end() - 2);
    }
    rebuild(ind, data);
}

void Mutation::apply(
    Individual& ind, const Data& data, std::mt19937& rng,
    double shakingPercent) {
    int internalCount = static_cast<int>(ind.sequence.size()) - 2;
    if (internalCount <= 0) return;

    int removeCount =
        std::max(1, static_cast<int>(internalCount * shakingPercent));
    std::vector<int> positions;
    for (int pos = 1; pos <= internalCount; ++pos) positions.push_back(pos);
    std::shuffle(positions.begin(), positions.end(), rng);
    positions.resize(removeCount);
    std::sort(positions.rbegin(), positions.rend());
    for (int pos : positions) ind.sequence.erase(ind.sequence.begin() + pos);
    repair(ind, data);

    std::unordered_set<int> selected(ind.sequence.begin(), ind.sequence.end());
    while (true) {
        int bestNode = -1;
        int bestPos = -1;
        double bestRatio = 0.0;
        double bestGain = 0.0;
        for (int node = 3; node <= data.n; ++node) {
            if (selected.count(node)) continue;
            for (size_t pos = 1; pos < ind.sequence.size(); ++pos) {
                int prev = ind.sequence[pos - 1];
                int next = ind.sequence[pos];
                double delta = data.tij[prev][node] + data.tij[node][next]
                    - data.tij[prev][next];
                if (ind.travelTime + delta > data.Tmax + 1e-9) continue;

                Individual trial = ind;
                trial.sequence.insert(trial.sequence.begin() + pos, node);
                trial.recomputeScores(data);
                double gain = trial.objective - ind.objective;
                double ratio = gain / std::max(delta, 1e-9);
                if (gain > 1e-9 &&
                    (ratio > bestRatio + 1e-12 ||
                     (std::abs(ratio - bestRatio) <= 1e-12 &&
                      gain > bestGain))) {
                    bestNode = node;
                    bestPos = static_cast<int>(pos);
                    bestRatio = ratio;
                    bestGain = gain;
                }
            }
        }
        if (bestNode < 0) break;
        ind.sequence.insert(ind.sequence.begin() + bestPos, bestNode);
        selected.insert(bestNode);
        ind.recomputeScores(data);
    }
}
