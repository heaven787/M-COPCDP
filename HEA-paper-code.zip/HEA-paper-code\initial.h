#ifndef INITIAL_SOLUTION_H
#define INITIAL_SOLUTION_H

#include "individual.h"
#include "readdata.h"

Individual buildInitialSolution(const Data& data);
void printSequenceOnly(const Individual& ind);
void printIndividual(const Individual& ind, const Data& data, int index = -1);

#endif
