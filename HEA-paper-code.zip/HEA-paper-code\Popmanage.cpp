﻿#include "Popmanage.h"
#include "crossover.h"
#include "mo.h"
#include <algorithm>
#include <cmath>
#include <unordered_set>

Popmanage::Popmanage(unsigned int seed, HeaConfig config)
    : config(std::move(config)), rng(seed) {}

double Popmanage::evaluate(const Individual& ind) const {
    return ind.objective;
}

Individual Popmanage::randomizedGreedy(const Data& data) {
    struct Insertion {
        int node;
        int position;
        double ratio;
        double gain;
    };

    Individual result;
    result.sequence = {1, 2};
    result.recomputeScores(data);
    std::unordered_set<int> selected = {1, 2};

    while (true) {
        std::vector<Insertion> candidates;
        for (int node = 3; node <= data.n; ++node) {
            if (selected.count(node)) continue;
            Insertion bestInsertion{node, -1, -1.0, 0.0};
            for (size_t pos = 1; pos < result.sequence.size(); ++pos) {
                int prev = result.sequence[pos - 1];
                int next = result.sequence[pos];
                double delta = data.tij[prev][node] + data.tij[node][next]
                    - data.tij[prev][next];
                if (result.travelTime + delta > data.Tmax + 1e-9) continue;
                Individual trial = result;
                trial.sequence.insert(trial.sequence.begin() + pos, node);
                trial.recomputeScores(data);
                double gain = trial.objective - result.objective;
                double ratio = gain / std::max(delta, 1e-9);
                if (gain > 1e-9 && ratio > bestInsertion.ratio) {
                    bestInsertion = {
                        node, static_cast<int>(pos), ratio, gain
                    };
                }
            }
            if (bestInsertion.position >= 0) candidates.push_back(bestInsertion);
        }
        if (candidates.empty()) break;
        std::sort(candidates.begin(), candidates.end(),
                  [](const Insertion& lhs, const Insertion& rhs) {
                      if (std::abs(lhs.ratio - rhs.ratio) > 1e-12)
                          return lhs.ratio > rhs.ratio;
                      return lhs.gain > rhs.gain;
                  });
        int restrictedSize = std::min<int>(3, candidates.size());
        std::uniform_int_distribution<int> choose(0, restrictedSize - 1);
        const Insertion& selectedInsertion = candidates[choose(rng)];
        result.sequence.insert(
            result.sequence.begin() + selectedInsertion.position,
            selectedInsertion.node);
        selected.insert(selectedInsertion.node);
        result.recomputeScores(data);
    }
    return result;
}

void Popmanage::initialize(const Data& data) {
    pool.clear();
    pool.reserve(config.popSize);
    for (int i = 0; i < config.popSize; ++i) pool.push_back(randomizedGreedy(data));
    best = *std::max_element(
        pool.begin(), pool.end(),
        [](const Individual& lhs, const Individual& rhs) {
            return lhs.objective < rhs.objective;
        });
}

const Individual& Popmanage::tournamentSelect() {
    std::uniform_int_distribution<int> choose(0, static_cast<int>(pool.size()) - 1);
    int bestIndex = choose(rng);
    for (int draw = 1; draw < TOURNAMENT_K; ++draw) {
        int index = choose(rng);
        if (evaluate(pool[index]) > evaluate(pool[bestIndex])) bestIndex = index;
    }
    return pool[bestIndex];
}

double Popmanage::jaccardSimilarity(
    const Individual& first, const Individual& second) const {
    std::unordered_set<int> firstSet;
    std::unordered_set<int> secondSet;
    if (first.sequence.size() > 2)
        firstSet.insert(first.sequence.begin() + 1, first.sequence.end() - 1);
    if (second.sequence.size() > 2)
        secondSet.insert(second.sequence.begin() + 1, second.sequence.end() - 1);
    int intersection = 0;
    for (int node : firstSet) {
        if (secondSet.count(node)) ++intersection;
    }
    int unionSize = static_cast<int>(firstSet.size() + secondSet.size()) - intersection;
    return unionSize == 0 ? 1.0
                          : static_cast<double>(intersection) / unionSize;
}

Individual Popmanage::evolve(
    const Data& data, LocalSearch& localSearch,
    const std::atomic<bool>& stopRequested) {
    initialize(data);
    int stagnation = 0;
    std::uniform_real_distribution<double> probability(0.0, 1.0);

    for (int generation = 0;
         generation < config.maxGen && !stopRequested.load();
         ++generation) {
        std::sort(pool.begin(), pool.end(),
                  [](const Individual& lhs, const Individual& rhs) {
                      return lhs.objective > rhs.objective;
                  });
        std::vector<Individual> next(
            pool.begin(), pool.begin() + config.eliteCount);
        next.reserve(config.popSize);

        while (static_cast<int>(next.size()) < config.popSize) {
            Individual parent1 = tournamentSelect();
            Individual parent2 = tournamentSelect();
            auto children = Crossover::apply(parent1, parent2, data, rng);
            Individual& child1 = children.first;
            Individual& child2 = children.second;

            double randomValue = probability(rng);
            bool mutate =
                jaccardSimilarity(child1, child2) >= config.simThreshold ||
                (stagnation > config.stagnationLim / 2 && randomValue > 0.5);
            if (mutate) {
                Mutation::apply(child1, data, rng, config.shakingPercent);
                Mutation::apply(child2, data, rng, config.shakingPercent);
            }
            child1 = localSearch.tabuSearch(child1);
            child2 = localSearch.tabuSearch(child2);
            next.push_back(std::move(child1));
            if (static_cast<int>(next.size()) < config.popSize)
                next.push_back(std::move(child2));
        }

        pool = std::move(next);
        const Individual& generationBest = *std::max_element(
            pool.begin(), pool.end(),
            [](const Individual& lhs, const Individual& rhs) {
                return lhs.objective < rhs.objective;
            });
        if (generationBest.objective > best.objective + 1e-9) {
            best = generationBest;
            stagnation = 0;
        } else {
            ++stagnation;
        }
    }
    best = localSearch.tabuSearch(best);
    return best;
}
