#ifndef READDATA_H
#define READDATA_H

#include <string>
#include <vector>

struct Data {
    int n;
    int NC;
    int Tmax;
    std::vector<double> x_coord;
    std::vector<double> y_coord;
    std::vector<int> si;
    std::vector<int> category;
    std::vector<double> alpha;
    std::vector<std::vector<double>> tij;
    std::vector<std::vector<int>> bic;
};

void readData(const std::string& filename, Data& data);

#endif
