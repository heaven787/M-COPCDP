#ifndef LOCAL_SEARCH_H
#define LOCAL_SEARCH_H

#include <random>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "individual.h"
#include "readdata.h"

class LocalSearch {
public:
    explicit LocalSearch(const Data& data, unsigned int seed = 123);
    void setParameters(int depth = 80, int threeOptFrequency = 5,
                       int penaltyFrequency = 5, double tenureFactor = 0.1);
    Individual tabuSearch(const Individual& initial);
    double calculateTotalDistance(const Individual& ind) const;
    double calculateTotalScore(const Individual& ind) const;
    bool isTimeFeasible(const Individual& ind) const;
    std::unordered_set<int> getNodesInSolution(const Individual& ind) const;

private:
    struct Move {
        int type = -1; // 0=ADD, 1=DROP, 2=SWAP
        int outgoingPosition = -1;
        int incomingNode = -1;
        int insertionPosition = -1;
        double value = 0.0;
        double objective = 0.0;
        double travelTime = 0.0;
        std::vector<int> attributes;
    };

    const Data& data;
    int depth = 80;
    int threeOptFrequency = 5;
    int penaltyFrequency = 5;
    double tenureFactor = 0.1;
    double penalty = 1.0;
    int consecutiveFeasible = 0;
    int consecutiveInfeasible = 0;
    std::unordered_map<int, int> tabuUntil;
    std::mt19937 rng;

    double penalizedValue(const Individual& ind) const;
    int tabuTenure();
    bool isTabu(const std::vector<int>& attributes, int iteration) const;
    void markTabu(const std::vector<int>& attributes, int iteration);
    std::pair<int, double> bestInsertion(const Individual& ind, int node) const;
    double categoryContribution(double sum, int count, int category) const;
    Move selectBestMove(const Individual& current,
                        const Individual& bestFeasible,
                        double bestPenalized,
                        int iteration);
    Individual applyMove(const Individual& current, const Move& move) const;
    void apply3Opt(Individual& ind);
    void updatePenalty(const Individual& current, int iteration);
};

#endif
