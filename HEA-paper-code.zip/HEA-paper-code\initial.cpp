#include "initial.h"
#include <algorithm>
#include <cstdio>
#include <iostream>

Individual buildInitialSolution(const Data& data) {
    Individual ind;
    ind.sequence = {1, 2};
    ind.recomputeScores(data);
    std::vector<bool> selected(data.n + 1, false);
    selected[1] = selected[2] = true;

    while (true) {
        int bestNode = -1;
        int bestPos = -1;
        double bestRatio = -1.0;
        for (int node = 3; node <= data.n; ++node) {
            if (selected[node]) continue;
            for (size_t pos = 1; pos < ind.sequence.size(); ++pos) {
                int prev = ind.sequence[pos - 1];
                int next = ind.sequence[pos];
                double delta = data.tij[prev][node] + data.tij[node][next]
                    - data.tij[prev][next];
                if (ind.travelTime + delta > data.Tmax + 1e-9) continue;
                Individual trial = ind;
                trial.sequence.insert(trial.sequence.begin() + pos, node);
                trial.recomputeScores(data);
                double gain = trial.objective - ind.objective;
                double ratio = gain / std::max(delta, 1e-9);
                if (ratio > bestRatio) {
                    bestRatio = ratio;
                    bestNode = node;
                    bestPos = static_cast<int>(pos);
                }
            }
        }
        if (bestNode < 0 || bestRatio <= 0.0) break;
        ind.sequence.insert(ind.sequence.begin() + bestPos, bestNode);
        selected[bestNode] = true;
        ind.recomputeScores(data);
    }
    return ind;
}

void printSequenceOnly(const Individual& ind) {
    for (size_t i = 0; i < ind.sequence.size(); ++i) {
        if (i) std::cout << ' ';
        std::cout << ind.sequence[i];
    }
    std::cout << '\n';
}

void printIndividual(const Individual& ind, const Data& data, int index) {
    if (index >= 0) std::cout << "Individual #" << index << '\n';

    std::cout << "Sequence: ";
    printSequenceOnly(ind);
    std::cout << "Categories: ";
    for (int category : ind.categories) std::cout << category << ' ';
    std::cout << "\nCounts: ";
    for (size_t category = 1; category < ind.counts.size(); ++category)
        std::cout << ind.counts[category] << ' ';
    std::cout << "\nScores: ";
    for (double score : ind.scores) std::printf("%.4f ", score);
    std::cout << "\nObjective: " << ind.objective
              << "\nDistance: " << ind.travelTime << " / " << data.Tmax
              << "\nPOIs: " << (ind.sequence.size() - 2) << "\n";
}
