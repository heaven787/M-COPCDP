﻿#include "LocalSearch.h"
#include <algorithm>
#include <cmath>
#include <limits>

LocalSearch::LocalSearch(const Data& data, unsigned int seed)
    : data(data), rng(seed) {}

void LocalSearch::setParameters(int newDepth, int newThreeOptFrequency,
                                int newPenaltyFrequency, double newTenureFactor) {
    depth = newDepth;
    threeOptFrequency = newThreeOptFrequency;
    penaltyFrequency = newPenaltyFrequency;
    tenureFactor = newTenureFactor;
}

double LocalSearch::calculateTotalDistance(const Individual& ind) const {
    return ind.travelTime;
}

double LocalSearch::calculateTotalScore(const Individual& ind) const {
    return ind.objective;
}

bool LocalSearch::isTimeFeasible(const Individual& ind) const {
    return ind.travelTime <= data.Tmax + 1e-9;
}

std::unordered_set<int> LocalSearch::getNodesInSolution(
    const Individual& ind) const {
    std::unordered_set<int> result;
    if (ind.sequence.size() <= 2) return result;
    result.insert(ind.sequence.begin() + 1, ind.sequence.end() - 1);
    return result;
}

double LocalSearch::penalizedValue(const Individual& ind) const {
    return ind.objective - penalty * std::max(0.0, ind.travelTime - data.Tmax);
}

int LocalSearch::tabuTenure() {
    std::uniform_int_distribution<int> extra(1, 10);
    return static_cast<int>(tenureFactor * std::max(0, data.n - 2)) + extra(rng);
}

bool LocalSearch::isTabu(
    const std::vector<int>& attributes, int iteration) const {
    for (int node : attributes) {
        auto it = tabuUntil.find(node);
        if (it != tabuUntil.end() && iteration < it->second) return true;
    }
    return false;
}

void LocalSearch::markTabu(
    const std::vector<int>& attributes, int iteration) {
    int until = iteration + tabuTenure();
    for (int node : attributes) tabuUntil[node] = until;
}

std::pair<int, double> LocalSearch::bestInsertion(
    const Individual& ind, int node) const {
    int bestPosition = -1;
    double bestDelta = std::numeric_limits<double>::infinity();
    for (size_t pos = 1; pos < ind.sequence.size(); ++pos) {
        int prev = ind.sequence[pos - 1];
        int next = ind.sequence[pos];
        double delta = data.tij[prev][node] + data.tij[node][next]
            - data.tij[prev][next];
        if (delta < bestDelta) {
            bestDelta = delta;
            bestPosition = static_cast<int>(pos);
        }
    }
    return {bestPosition, bestDelta};
}

double LocalSearch::categoryContribution(
    double sum, int count, int category) const {
    if (count <= 0 || category < 1 || category > data.NC) return 0.0;
    return sum / ((1.0 - data.alpha[category]) * (count + 1));
}

LocalSearch::Move LocalSearch::selectBestMove(
    const Individual& current, const Individual& bestFeasible,
    double bestPenalized, int iteration) {
    Move best;
    best.value = -std::numeric_limits<double>::infinity();
    auto selected = getNodesInSolution(current);
    std::vector<int> unselected;
    for (int node = 3; node <= data.n; ++node) {
        if (!selected.count(node)) unselected.push_back(node);
    }

    auto consider = [&](int type, int outgoingPosition, int incomingNode,
                        int insertionPosition, double objective,
                        double travelTime, std::vector<int> attributes) {
        double value = objective -
            penalty * std::max(0.0, travelTime - data.Tmax);
        bool aspiration =
            (travelTime <= data.Tmax + 1e-9 &&
             objective > bestFeasible.objective + 1e-9) ||
            value > bestPenalized + 1e-9;
        if ((!isTabu(attributes, iteration) || aspiration) &&
            value > best.value) {
            best = {type, outgoingPosition, incomingNode, insertionPosition,
                    value, objective, travelTime, std::move(attributes)};
        }
    };

    for (int node : unselected) {
        auto [position, delta] = bestInsertion(current, node);
        int category = data.category[node];
        double oldContribution = categoryContribution(
            current.categorySums[category], current.counts[category], category);
        double newContribution = categoryContribution(
            current.categorySums[category] + data.si[node],
            current.counts[category] + 1, category);
        consider(0, -1, node, position,
                 current.objective - oldContribution + newContribution,
                 current.travelTime + delta, {node});
    }

    for (size_t pos = 1; pos + 1 < current.sequence.size(); ++pos) {
        int node = current.sequence[pos];
        int category = data.category[node];
        double oldContribution = categoryContribution(
            current.categorySums[category], current.counts[category], category);
        double newContribution = categoryContribution(
            current.categorySums[category] - data.si[node],
            current.counts[category] - 1, category);
        int prev = current.sequence[pos - 1];
        int next = current.sequence[pos + 1];
        double distance = current.travelTime + data.tij[prev][next]
            - data.tij[prev][node] - data.tij[node][next];
        consider(1, static_cast<int>(pos), -1, -1,
                 current.objective - oldContribution + newContribution,
                 distance, {node});
    }

    // Pre-sort insertion deltas because a drop replaces only two edges.
    for (int incoming : unselected) {
        std::vector<std::pair<double, int>> edgeOptions;
        edgeOptions.reserve(current.sequence.size() - 1);
        for (size_t edge = 0; edge + 1 < current.sequence.size(); ++edge) {
            int left = current.sequence[edge];
            int right = current.sequence[edge + 1];
            double delta = data.tij[left][incoming] + data.tij[incoming][right]
                - data.tij[left][right];
            edgeOptions.push_back({delta, static_cast<int>(edge)});
        }
        std::sort(edgeOptions.begin(), edgeOptions.end());

        for (size_t pos = 1; pos + 1 < current.sequence.size(); ++pos) {
            int outgoing = current.sequence[pos];
            int prev = current.sequence[pos - 1];
            int next = current.sequence[pos + 1];
            double removalDelta = data.tij[prev][next]
                - data.tij[prev][outgoing] - data.tij[outgoing][next];

            double insertionDelta = data.tij[prev][incoming]
                + data.tij[incoming][next] - data.tij[prev][next];
            int insertionPosition = static_cast<int>(pos);
            for (const auto& option : edgeOptions) {
                int edge = option.second;
                if (edge == static_cast<int>(pos) - 1 ||
                    edge == static_cast<int>(pos)) continue;
                if (option.first < insertionDelta) {
                    insertionDelta = option.first;
                    insertionPosition =
                        edge < static_cast<int>(pos) - 1 ? edge + 1 : edge;
                }
                break;
            }

            int outCategory = data.category[outgoing];
            int inCategory = data.category[incoming];
            double objective = current.objective;
            if (outCategory == inCategory) {
                double oldContribution = categoryContribution(
                    current.categorySums[outCategory],
                    current.counts[outCategory], outCategory);
                double newContribution = categoryContribution(
                    current.categorySums[outCategory] - data.si[outgoing]
                        + data.si[incoming],
                    current.counts[outCategory], outCategory);
                objective += newContribution - oldContribution;
            } else {
                double oldOut = categoryContribution(
                    current.categorySums[outCategory],
                    current.counts[outCategory], outCategory);
                double newOut = categoryContribution(
                    current.categorySums[outCategory] - data.si[outgoing],
                    current.counts[outCategory] - 1, outCategory);
                double oldIn = categoryContribution(
                    current.categorySums[inCategory],
                    current.counts[inCategory], inCategory);
                double newIn = categoryContribution(
                    current.categorySums[inCategory] + data.si[incoming],
                    current.counts[inCategory] + 1, inCategory);
                objective += newOut - oldOut + newIn - oldIn;
            }
            consider(2, static_cast<int>(pos), incoming, insertionPosition,
                     objective, current.travelTime + removalDelta + insertionDelta,
                     {outgoing, incoming});
        }
    }
    return best;
}

Individual LocalSearch::applyMove(
    const Individual& current, const Move& move) const {
    Individual result = current;
    if (move.type == 0) {
        result.sequence.insert(
            result.sequence.begin() + move.insertionPosition, move.incomingNode);
    } else if (move.type == 1) {
        result.sequence.erase(result.sequence.begin() + move.outgoingPosition);
    } else if (move.type == 2) {
        result.sequence.erase(result.sequence.begin() + move.outgoingPosition);
        result.sequence.insert(
            result.sequence.begin() + move.insertionPosition, move.incomingNode);
    }
    result.recomputeScores(data);
    return result;
}

void LocalSearch::apply3Opt(Individual& ind) {
    const int size = static_cast<int>(ind.sequence.size());
    if (size < 6) return;

    double bestGain = 1e-9;
    int bestI = -1, bestJ = -1, bestK = -1, bestCase = 0;
    for (int i = 0; i < size - 5; ++i) {
        for (int j = i + 2; j < size - 3; ++j) {
            for (int k = j + 2; k < size - 1; ++k) {
                int a = ind.sequence[i], b = ind.sequence[i + 1];
                int c = ind.sequence[j], d = ind.sequence[j + 1];
                int e = ind.sequence[k], f = ind.sequence[k + 1];
                double oldEdges = data.tij[a][b] + data.tij[c][d] + data.tij[e][f];
                double alternatives[7] = {
                    data.tij[a][c] + data.tij[b][d] + data.tij[e][f],
                    data.tij[a][b] + data.tij[c][e] + data.tij[d][f],
                    data.tij[a][c] + data.tij[b][e] + data.tij[d][f],
                    data.tij[a][d] + data.tij[e][b] + data.tij[c][f],
                    data.tij[a][e] + data.tij[d][b] + data.tij[c][f],
                    data.tij[a][d] + data.tij[e][c] + data.tij[b][f],
                    data.tij[a][e] + data.tij[d][c] + data.tij[b][f]
                };
                for (int type = 0; type < 7; ++type) {
                    double gain = oldEdges - alternatives[type];
                    if (gain > bestGain) {
                        bestGain = gain;
                        bestI = i; bestJ = j; bestK = k; bestCase = type + 1;
                    }
                }
            }
        }
    }
    if (bestI < 0) return;

    std::vector<int> prefix(ind.sequence.begin(), ind.sequence.begin() + bestI + 1);
    std::vector<int> first(ind.sequence.begin() + bestI + 1,
                           ind.sequence.begin() + bestJ + 1);
    std::vector<int> second(ind.sequence.begin() + bestJ + 1,
                            ind.sequence.begin() + bestK + 1);
    std::vector<int> suffix(ind.sequence.begin() + bestK + 1, ind.sequence.end());
    if (bestCase == 1 || bestCase == 3 || bestCase == 6 || bestCase == 7)
        std::reverse(first.begin(), first.end());
    if (bestCase == 2 || bestCase == 3 || bestCase == 5 || bestCase == 7)
        std::reverse(second.begin(), second.end());
    if (bestCase >= 4) std::swap(first, second);
    ind.sequence = prefix;
    ind.sequence.insert(ind.sequence.end(), first.begin(), first.end());
    ind.sequence.insert(ind.sequence.end(), second.begin(), second.end());
    ind.sequence.insert(ind.sequence.end(), suffix.begin(), suffix.end());
    ind.recomputeScores(data);
}

void LocalSearch::updatePenalty(const Individual& current, int iteration) {
    if (isTimeFeasible(current)) {
        ++consecutiveFeasible;
        consecutiveInfeasible = 0;
    } else {
        ++consecutiveInfeasible;
        consecutiveFeasible = 0;
    }
    if ((iteration + 1) % penaltyFrequency != 0) return;
    if (consecutiveFeasible >= penaltyFrequency) {
        penalty /= 2.0;
        consecutiveFeasible = 0;
    } else if (consecutiveInfeasible >= penaltyFrequency) {
        penalty *= 2.0;
        consecutiveInfeasible = 0;
    }
}

Individual LocalSearch::tabuSearch(const Individual& initial) {
    Individual current = initial;
    current.recomputeScores(data);
    penalty = 1.0;
    consecutiveFeasible = consecutiveInfeasible = 0;
    tabuUntil.clear();
    Individual bestFeasible = current;
    Individual bestEvaluated = current;
    double bestPenalized = penalizedValue(current);

    for (int iteration = 0; iteration < depth; ++iteration) {
        Move bestMove = selectBestMove(
            current, bestFeasible, bestPenalized, iteration);
        if (bestMove.type < 0) break;
        current = applyMove(current, bestMove);
        markTabu(bestMove.attributes, iteration);

        if ((iteration + 1) % threeOptFrequency == 0) apply3Opt(current);
        double value = penalizedValue(current);
        if (value > bestPenalized) {
            bestPenalized = value;
            bestEvaluated = current;
        }
        if (isTimeFeasible(current) &&
            current.objective > bestFeasible.objective + 1e-9) {
            bestFeasible = current;
        }
        updatePenalty(current, iteration);
    }
    (void)bestEvaluated;
    return bestFeasible;
}
