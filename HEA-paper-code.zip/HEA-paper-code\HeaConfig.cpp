#include "HeaConfig.h"
#include <stdexcept>

void HeaConfig::applyFlag(const std::string& key, const std::string& value) {
    const double dval = std::stod(value);
    const int ival = static_cast<int>(std::stod(value));

    if (key == "pop") popSize = ival;
    else if (key == "elite") eliteCount = ival;
    else if (key == "gen") maxGen = ival;
    else if (key == "stagnation") stagnationLim = ival;
    else if (key == "sim") simThreshold = dval;
    else if (key == "shake") shakingPercent = dval;
    else if (key == "L") tabuDepth = ival;
    else if (key == "uc") threeOptFreq = ival;
    else if (key == "up") penaltyFreq = ival;
    else if (key == "beta") tenureFactor = dval;
    else throw std::runtime_error("Unknown parameter flag: " + key);
}
