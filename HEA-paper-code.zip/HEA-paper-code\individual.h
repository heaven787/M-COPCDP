#ifndef INDIVIDUAL_H
#define INDIVIDUAL_H

#include <vector>
#include "readdata.h"

class Individual {
public:
    // Complete route from node 1 to node 2.
    std::vector<int> sequence;
    std::vector<int> categories;
    std::vector<int> counts;
    std::vector<double> categorySums;
    std::vector<double> scores;
    double objective = 0.0;
    double travelTime = 0.0;

    Individual() = default;
    void recomputeScores(const Data& data);
};

#endif // INDIVIDUAL_H